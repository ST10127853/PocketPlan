package com.example.authentification.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.authentification.data.dao.ExpenseDao
import com.example.authentification.data.entities.Expense


class ExpenseViewModel(private val expenseDao: ExpenseDao) : ViewModel() {
    fun getAllExpenses(userId: Int): LiveData<List<Expense>> = expenseDao.getAllExpenses(userId)

    fun addExpense(expense: Expense) = viewModelScope.launch {
        expenseDao.insert(expense)
    }

    fun deleteExpense(expense: Expense) = viewModelScope.launch {
        expenseDao.delete(expense)
    }
}