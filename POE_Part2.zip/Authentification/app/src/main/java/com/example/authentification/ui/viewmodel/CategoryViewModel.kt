package com.example.authentification.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.authentification.data.entities.Category

import com.example.budgettracker.repository.CategoryRepository
import kotlinx.coroutines.launch

class CategoryViewModel(private val repository: CategoryRepository) : ViewModel() {

    // Using LiveData and Flow to observe categories in a lifecycle-aware way
    val allCategories = repository.allCategories.asLiveData()

    /**
     * Launching a new coroutine to insert the category in a non-blocking way
     */
    fun insert(category: Category) = viewModelScope.launch {
        repository.insert(category)
    }
}

class CategoryViewModelFactory(private val repository: CategoryRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CategoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CategoryViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}