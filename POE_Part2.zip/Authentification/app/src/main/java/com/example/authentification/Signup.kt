package com.example.authentification

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Signup : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup_main)
    }
}